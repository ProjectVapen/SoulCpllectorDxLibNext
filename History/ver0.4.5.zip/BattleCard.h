#pragma once
#include "Include.h"
class BattleCard
{
	public:
		BattleCard();
		~BattleCard();
};

