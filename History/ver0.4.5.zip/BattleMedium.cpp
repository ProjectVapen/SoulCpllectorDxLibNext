#include "BattleMedium.h"


BattleMedium::BattleMedium()
{
}


BattleMedium::~BattleMedium()
{
}
