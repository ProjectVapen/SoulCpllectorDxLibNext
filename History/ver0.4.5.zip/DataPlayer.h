#pragma once
#include "Include.h"
class DataPlayer
{
public:
	DataPlayer();
	~DataPlayer();
};

