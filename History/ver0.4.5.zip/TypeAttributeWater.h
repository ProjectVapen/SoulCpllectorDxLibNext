#pragma once
#include "TypeAttributeBase.h"
#include "Include.h"
class TypeAttributeWater :
	public TypeAttributeBase
{
public:
	TypeAttributeWater();
	~TypeAttributeWater();
};

