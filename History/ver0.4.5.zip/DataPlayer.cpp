#include "DataPlayer.h"


DataPlayer::DataPlayer()
{
}


DataPlayer::~DataPlayer()
{
}
