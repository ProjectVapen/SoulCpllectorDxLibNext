#pragma once
#include "Include.h"
class DataMedium
{
public:
	DataMedium();
	~DataMedium();
};

