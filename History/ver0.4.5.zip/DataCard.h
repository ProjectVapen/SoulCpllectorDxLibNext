#pragma once
#include "Include.h"
class DataCard
{
public:
	DataCard();
	~DataCard();
};

