#pragma once
#include "Include.h"
class BattlePlayer
{
public:
	BattlePlayer();
	~BattlePlayer();
};

