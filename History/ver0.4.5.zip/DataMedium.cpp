#include "DataMedium.h"


DataMedium::DataMedium()
{
}


DataMedium::~DataMedium()
{
}
