#include "TypeCardMagic.h"


TypeCardMagic::TypeCardMagic()
{
}


TypeCardMagic::~TypeCardMagic()
{
}
