#include "TypeAttributeWind.h"


TypeAttributeWind::TypeAttributeWind()
{
}


TypeAttributeWind::~TypeAttributeWind()
{
}
