#include "DataCard.h"


DataCard::DataCard()
{
}


DataCard::~DataCard()
{
}
