#include "SceneResult.h"
#include "Application.h"

SceneResult::SceneResult()
{
}


SceneResult::~SceneResult()
{
}

void SceneResult::Render(){

}
void SceneResult::ImageDelete(){
	///DeleteGraph(m_backImage);
}