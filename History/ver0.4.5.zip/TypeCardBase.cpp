#include "TypeCardBase.h"


TypeCardBase::TypeCardBase()
{
}


TypeCardBase::~TypeCardBase()
{
}
