#pragma once
class TypeCardBase
{
public:
	TypeCardBase();
	~TypeCardBase();
};

