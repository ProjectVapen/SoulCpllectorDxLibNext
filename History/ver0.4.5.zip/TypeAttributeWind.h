#pragma once
#include "TypeAttributeBase.h"
#include "Include.h"
class TypeAttributeWind :
	public TypeAttributeBase
{
public:
	TypeAttributeWind();
	~TypeAttributeWind();
};

