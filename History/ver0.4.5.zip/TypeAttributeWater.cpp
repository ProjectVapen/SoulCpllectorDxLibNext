#include "TypeAttributeWater.h"


TypeAttributeWater::TypeAttributeWater()
{
}


TypeAttributeWater::~TypeAttributeWater()
{
}
