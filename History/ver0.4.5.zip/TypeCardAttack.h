#pragma once
#include "TypeCardBase.h"
#include "Include.h"
class TypeCardAttack:
	public TypeCardBase
{
public:
	TypeCardAttack();
	~TypeCardAttack();
};

